import React from "react";
import {
  Slider,
  Chip,
  Container,
} from '@mui/material';

const clamp = (num, min, max) => Math.min(Math.max(num, min), max);

function yuv2rgb(y, u, v) {
  y = parseInt(y);
  u = parseInt(u);
  v = parseInt(v);

  const r = clamp(Math.floor(y + 1.4075 * (v - 128)), 0, 255);
  const g = clamp(Math.floor(y - 0.3455 * (u - 128) - (0.7169 * (v - 128))), 0, 255);
  const b = clamp(Math.floor(y + 1.7790 * (u - 128)), 0, 255);

  return ({ r: r, g: g, b: b });
}


const ImageAdjustment = () => {
  return (
    <Container>
      <Chip label="Chip Outlined" variant="outlined" />
      <Slider defaultValue={30} />
    </Container>
  );
}

export default ImageAdjustment;